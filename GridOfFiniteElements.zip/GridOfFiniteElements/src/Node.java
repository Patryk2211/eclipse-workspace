
public class Node {
	private float x, y, t_0;

	public Node(float f, float g, int t_0) {
		super();
		this.x = f;
		this.y = g;
		this.t_0 = t_0;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getT_0() {
		return t_0;
	}

	public void setT_0(float t_0) {
		this.t_0 = t_0;
	}
	
}
